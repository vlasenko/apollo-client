# Change log

### vNEXT
- Refactored type usage
- Prevented logging on defered queries
- Refactored internal store from apollo-client into own package
