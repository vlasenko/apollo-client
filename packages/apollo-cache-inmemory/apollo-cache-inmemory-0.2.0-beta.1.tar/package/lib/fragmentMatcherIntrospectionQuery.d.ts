declare const query: any;
export default query;
